
package modelo;

import java.io.Serializable;
import servicio.CSVserializable;


public class Animal implements Comparable<Animal>, CSVserializable, Serializable {
   private static final long SerialVersionUID = 1l;
   private int id;
   private String nombre;
   private String especie;
   private TipoAlimentacion alimentacion;

    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }

    @Override
    public String toString() {
        return "Animal{" + "id=" + id + ", nombre=" + nombre + ", especie=" + especie + ", alimentacion=" + alimentacion + '}';
    }
   


    @Override
    public int compareTo(Animal o) {
        return  Integer.compare(id, o.id);
    }

    @Override
    public String toCSV() {
    return id + "," + nombre + "," + especie + "," + alimentacion;    }
   
    
    public static Animal fromCSV(String animalCSV){
        
        if (animalCSV.endsWith("\n")){
            animalCSV = animalCSV.substring(0, animalCSV.length() - 1);
        }
        
        String[] valores = animalCSV.split(",");
        
        return new Animal(Integer.parseInt(valores[0]),
        valores[1],
        valores[2],
                TipoAlimentacion.valueOf(valores[3]));
        
        
    }
}   
