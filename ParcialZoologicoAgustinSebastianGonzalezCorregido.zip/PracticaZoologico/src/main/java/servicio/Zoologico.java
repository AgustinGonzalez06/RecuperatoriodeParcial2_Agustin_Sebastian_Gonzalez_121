
package servicio;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Zoologico<T extends CSVserializable> implements Inventariable<T>{
    
    List<T> Lista = new ArrayList<>();
    
    @Override
    public void agregar(T item) {
           Lista.add(item);
    }


    @Override
    public T obtener(int indice) {
     return Lista.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        Lista.remove(indice);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicado) {
        List<T> toReturn = new ArrayList<>();
        for(T item: Lista){
            if(predicado.test(item)){
                toReturn.add(item);
            }
        }
        return toReturn;

                
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        Lista.sort(comparador);
    }

    @Override
    public void ordenar() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void serializar(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))){
            salida.writeObject(Lista);
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void deserializar(String path) {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))){
            Lista = (List<T>)input.readObject();
        }catch (IOException | ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void saveCSV(String path) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))){
            bw.write("id,nombre,especie,alimentacion\n");
        }catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void loadCSV(String path, Function<String, T> funcion) {
        Lista.clear();
        try(BufferedReader bf = new BufferedReader(new FileReader(path))){
            String linea;
            bf.readLine();
            while((linea = bf.readLine())!= null){
                Lista.add(funcion.apply(linea));
            }
        }catch (IOException ex){
                    System.out.println(ex.getMessage());
                    throw new RuntimeException("Error en archivo");
                    }
        }
    


    @Override
    public void paraCadaElemento(Consumer<T> consumidor) {
        for(T item: Lista) {
            consumidor.accept(item);
        }
    }




}
