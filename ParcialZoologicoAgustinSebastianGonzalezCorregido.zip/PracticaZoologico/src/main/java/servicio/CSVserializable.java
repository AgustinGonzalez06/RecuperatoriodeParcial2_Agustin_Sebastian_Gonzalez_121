
package servicio;

@FunctionalInterface
public interface CSVserializable {
    String toCSV(); 
}
